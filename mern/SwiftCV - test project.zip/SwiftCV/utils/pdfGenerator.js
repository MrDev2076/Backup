const pdf = require('html-pdf');
const fs = require('fs');
const path = require('path');

// Ensure the output directory exists
const outputDir = path.join(__dirname, '../generated_pdfs');
if (!fs.existsSync(outputDir)) {
    fs.mkdirSync(outputDir);
}

function generateResume(userData, callback) {
    const templatePath = path.join(__dirname, '../views/resume_template.html');
    const filePath = path.join(outputDir, `resume_${userData.name.replace(/\s+/g, '_')}.pdf`);

    // Read the HTML template
    fs.readFile(templatePath, 'utf8', (err, data) => {
        if (err) {
            console.error(`Error reading template: ${err.message}`);
            return callback(err);
        }

        // Replace placeholders with user data
        const html = data
            .replace(/{{name}}/g, userData.name)
            .replace(/{{contact}}/g, userData.contact)
            .replace(/{{education}}/g, userData.education)
            .replace(/{{experience}}/g, userData.experience)
            .replace(/{{skills}}/g, userData.skills);

        // Generate the PDF from HTML
        pdf.create(html).toFile(filePath, (err, res) => {
            if (err) {
                console.error(`Error creating PDF: ${err.message}`);
                return callback(err);
            }
            console.log(`PDF generated at: ${res.filename}`);
            callback(null); // Call the callback with no error
        });
    });
}

module.exports = { generateResume };
