// Form validation before submission
document.addEventListener('DOMContentLoaded', () => {
    const form = document.querySelector('form');
    const nameInput = document.getElementById('name');
    const contactInput = document.getElementById('contact');
    const educationTextarea = document.getElementById('education');
    const experienceTextarea = document.getElementById('experience');
    const skillsTextarea = document.getElementById('skills');
    
    form.addEventListener('submit', (event) => {
        let isValid = true;

        // Validate name
        if (nameInput.value.trim() === '') {
            alert('Please enter your name.');
            isValid = false;
        }

        // Validate contact
        if (contactInput.value.trim() === '') {
            alert('Please enter your contact details.');
            isValid = false;
        }

        // Check if education details are entered
        if (educationTextarea.value.trim() === '') {
            alert('Please enter your education details.');
            isValid = false;
        }

        if (!isValid) {
            event.preventDefault();  // Prevent form submission if invalid
        }
    });

    // Character counters for the text areas
    const charCounters = {
        education: document.createElement('span'),
        experience: document.createElement('span'),
        skills: document.createElement('span'),
    };

    function updateCharCount(textarea, counter) {
        counter.textContent = `Characters: ${textarea.value.length}`;
    }

    Object.entries(charCounters).forEach(([field, counter]) => {
        const textarea = document.getElementById(field);
        textarea.parentNode.insertBefore(counter, textarea.nextSibling);
        textarea.addEventListener('input', () => updateCharCount(textarea, counter));
        updateCharCount(textarea, counter); // Initialize count on page load
    });
});
